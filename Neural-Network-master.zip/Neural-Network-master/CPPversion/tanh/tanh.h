#ifndef TANH_H
#define TANH_H

#include "../activation/activation.h"

class Tanh : public Activation {
    public:
        Tanh();
};

#endif