#include "dataGetter.ih"

DataGetter::DataGetter() {}