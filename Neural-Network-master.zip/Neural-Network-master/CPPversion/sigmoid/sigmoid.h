#ifndef SIGMOID_H
#define SIGMOID_H

#include "../activation/activation.h"

class Sigmoid : public Activation {
    public:
        Sigmoid();
};

#endif